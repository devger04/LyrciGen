import os
import time

os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE" # make torch import work on my machine - jacob

# imports
import torch
from torch.nn.functional import cosine_similarity
from transformers import DistilBertTokenizer, DistilBertModel
import pandas as pd
# Load pre-trained model tokenizer and model
tokenizer = DistilBertTokenizer.from_pretrained('distilbert-base-uncased')
model = DistilBertModel.from_pretrained('distilbert-base-uncased')

# # store API tokens in environment variables
# load_dotenv()

def encode_sentences(sentences):
    inputs = tokenizer(sentences, padding=True, truncation=True, return_tensors='pt')
    return inputs

def get_embeddings(sentences):
    inputs = encode_sentences(sentences)
    with torch.no_grad():
        outputs = model(**inputs)
    cls_embeddings = outputs.last_hidden_state[:, 0, :]  # Get the [CLS] token embeddings
    return cls_embeddings

def compute_similarity(sentence1, sentence2):
    embeddings = get_embeddings([sentence1, sentence2])
    similarity = cosine_similarity(embeddings[0].unsqueeze(0), embeddings[1].unsqueeze(0))
    return similarity.item()

### COMPUTE ALL SEMANTIC SIMILARITIES FROM MODEL OUTPUT###
results_df = pd.read_csv('../results/results.csv')
similarities = []
for row in results_df.itertuples():
    similarities.append(compute_similarity(row.original_lyrics, row.generated_lyrics))
results_df['similarities'] = similarities
results_df.to_csv('../results/similarities.csv', index=False)
