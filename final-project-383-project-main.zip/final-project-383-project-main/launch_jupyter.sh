#!/bin/bash

source tokens.sh
sh tokens.sh
jupyter notebook
